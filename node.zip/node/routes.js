const HomeController = require('./HomeController')
const Route = require('./RouteHandaler')

var routes = [
    Route.get("/", HomeController, "index"),
    Route.get("/about", HomeController, "about"),
    Route.get("/500", HomeController, "about2")
]
module.exports = {routes, HomeController}