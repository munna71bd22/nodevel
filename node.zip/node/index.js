const http = require('http')
const router = require('./routes')
fs = require('fs');


console.log("server is starting on port 3000")

const server = http.createServer((req, res) => {

    var route = router.routes.find(route => route.name === req.url)

    if (route) {
        if (route.method === req.method) {
            try {
                var x = new route.controller()
                var action = route.action
                var filePath = eval("x." + route.action + "()")

                fs.readFile(filePath, null, function (error, data) {
                    if (error) {
                        res.writeHead(404);
                        res.write('Whoops! File not found!');
                        res.end()
                    } else {
                        res.writeHead(200, {'Content-Type': 'text/html'});
                        res.write(data);
                        res.end()
                    }
                });


            } catch (err) {
                fs.readFile("./500.html", null, function (error, data) {
                    if (error) {
                        res.writeHead(500);
                        res.write('500 Internal Server Error!');
                        res.end()
                    } else {
                        res.writeHead(200, {'Content-Type': 'text/html'});
                        res.write(data);
                        res.end()
                    }
                });
            }
        } else {
            res.write("Method Not Allowed!")
            res.end()
        }
    } else {
        fs.readFile("./404.html", null, function (error, data) {
            if (error) {
                res.writeHead(404);
                res.write('Whoops! File not found!');
                res.end()
            } else {
                res.writeHead(200, {'Content-Type': 'text/html'});
                res.write(data);
                res.end()
            }
        });
    }
})
server.listen(3000,'192.168.1.170')
