class HomeController {
    index() {
        return './index.html'
    }

    about() {
        return './about.html'
    }
}

module.exports = HomeController